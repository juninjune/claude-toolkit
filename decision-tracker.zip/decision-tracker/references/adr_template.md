# [번호] [제목]

**Status**: [Proposed/Accepted/Deprecated/Superseded]
**Date**: YYYY-MM-DD
**Decision Makers**: Claude Code + User
**Tags**: [architecture, library-choice, performance, security, etc.]

## Context

[왜 이 결정이 필요했는가? 어떤 문제나 상황이 이 결정을 유발했는가?]

## Decision

[무엇을 결정했는가? 명확하고 간결하게 기술]

## Alternatives Considered

[고려했던 다른 옵션들과 각각을 채택하지 않은 이유]

- **Option A**: [설명] - [채택하지 않은 이유]
- **Option B**: [설명] - [채택하지 않은 이유]

## Consequences

### Positive

- [이 결정의 긍정적 영향]
- [기대되는 이점]

### Negative

- [부정적 영향이나 Trade-offs]
- [주의해야 할 제약사항]

## Implementation Notes

[구현 시 고려사항, 마이그레이션 계획, 중요한 기술적 디테일]

## Related Sessions

- [YYYYMMDD_HHMM](../path/to/session.md) - [세션 요약]

## Related Decisions

- [ADR-XXXX](./XXXX-title.md) - [관련 결정 요약]
